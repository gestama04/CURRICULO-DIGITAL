import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;          //todos os imports que utilizamos
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.swing.Timer;

public class SpaceInvaders extends JPanel implements KeyListener, ActionListener {
    private int playerX = 600;             //comprimento do player
    private List<Enemy> enemies;           //lista dos inimigos
    private boolean isGameOver = false;    //booleano para verificar se o jogo acabou ou nao
    private boolean isFiring = false;      //booleano para verificar se o player está a disparar
    private List<Missile> missiles;        //lista para as balas disparadas
    private Timer timer;                   //tempo de vida dos inimigos
    private Timer missileTimer;            //tempo de vida das balas
    private int level = 1;                 //o nivel começa no 1
    private Random random;                 //random para o numero de inimigos
    private int maxEnemies = 6;            //numero maximo de inimigos
    private double enemySpeed = 1.10;      //velocidade dos inimigos
    private boolean isPaused = false;      //booleano para verificar se o jogo está em pausa
    private JButton pauseButton;           //botao da pausa


     
    public SpaceInvaders() {
        setPreferredSize(new Dimension(1500, 800)); //dimensoes da tela
        setBackground(Color.BLACK);                              //cor do fundo
        setFocusable(true);                            //coloca o foco
        addKeyListener(this);                                    //lê as teclas quando pressionadas

        enemies = new ArrayList<>();      //array dos inimigos
        missiles = new ArrayList<>();     //array dos tiros
        random = new Random();

        timer = new Timer(5, this);
        timer.start();

        missileTimer = new Timer(200, new ActionListener() {   //tempo que demora a ler o espaço para disparar
            public void actionPerformed(ActionEvent e) {
                if (isFiring && missiles.size() < 10) {
                    missiles.add(new Missile(playerX + 50, 770));  //adiciona um tiro ao player, ou seja, dispara
                }
            }
        });
        missileTimer.start();

        createEnemies();    //invoca a funçao para criar os inmigos

        pauseButton = new JButton("Pause");             //botao da pausa
        pauseButton.setFocusable(false);           //coloca o foco
        pauseButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (isGameOver) {                       //se o jogo acabar não pausa porque acabou o jogo
                    return;
                }
                isPaused = !isPaused;            
                if (isPaused) {                         //se o jogo estiver pausado para tudo
                    pauseButton.setText("Resume");
                    timer.stop();
                    missileTimer.stop();
                } else {                                //volta tudo quando despausar o jogo
                    pauseButton.setText("Pause");
                    timer.start();
                    missileTimer.start();
                }
            }
        });
        add(pauseButton);                               //adiciona o botao a tela
    }

    private void createEnemies() {
        enemies.clear();           //remove todos os inimigos da tela
        int numEnemies;

        if (level <= 4) {                    //no nivel 1 só tem 1 inimigo
            numEnemies = 1;
        } else {
            numEnemies = random.nextInt(maxEnemies) + 1; //nos restantes o n de inimigos é aleatorio
        }

        int startX = 50;     //ponto de começo dos aliens na tela
        int startY = 50;
        int spacingX = 150;  //espaço entre eles
        int spacingY = 80;

        boolean firstLineFull = false;
        for (int i = 0; i < numEnemies; i++) {
            boolean isBlue = random.nextInt(10) == 0;  //10% de chance de ser azul 
            if (!firstLineFull && i < 7) {
                enemies.add(new Enemy(startX + i * spacingX, startY, isBlue));  //se a linha nao tiver mais que 7 inimigos pode ter um azul
                if (i == 6) {
                    firstLineFull = true;
                }
            } else {
                enemies.add(new Enemy(startX + (i - 7) * spacingX, startY + spacingY, isBlue));
            }
        }
    }



    public void paintComponent(Graphics g) {         //metodo para pintar os objetos
        super.paintComponent(g);

        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());

        if (isGameOver) {                   
            g.setColor(Color.WHITE);                                 //cor do texto
            g.setFont(new Font("Arial", Font.BOLD, 30));   //fonte do texto
            String gameOverMsg = "Game Over";                        //texto para quando o jogo acabar
            g.drawString(gameOverMsg, getWidth() / 2 - g.getFontMetrics().stringWidth(gameOverMsg) / 2, getHeight() / 2);  //posicao do texto
        } else {
            g.setColor(Color.GREEN);                           //cor do player
            g.fillRect(playerX, 770, 100, 20);  //altura na tela no player; compirmento e altura do player

            for (Enemy enemy : enemies) {
                if (enemy.isBlue()) {
                    g.setColor(Color.BLUE);         //dá cor ao inimigo azul
                } else {
                    g.setColor(Color.RED);          //dá cor ao inimigo vermelho
                }
                g.fillRect(enemy.getX(), enemy.getY(), 40, 20);   //dimensoes dos aliens
            }

            for (Missile missile : missiles) {
                g.setColor(Color.YELLOW);            //dá cor ao disparo do player
                g.fillRect(missile.getX(), missile.getY(), 4, 20);  //dimensoes do disparo
            }

            g.setColor(Color.WHITE);         //cor do texto do nivel atual(canto inferior esquerdo)
            g.setFont(new Font("Arial", Font.PLAIN, 16));  //tipo de letra e tamanho
            String levelMsg = "Level: " + level;                     //adiciona o texto à tela
            g.drawString(levelMsg, 10, getHeight() - 30);          //posicão do texto
        }
    }

    public void keyTyped(KeyEvent e) {}            //é invocado quando a tecla é digitada  

    public void keyPressed(KeyEvent e) {           //é invocado assim que a tecla for pressionada
        int keyCode = e.getKeyCode();

        if (keyCode == KeyEvent.VK_LEFT) {         //movimenta o player para a esquerda
            if (playerX > 0) {
                playerX -= 10;
            }
        } else if (keyCode == KeyEvent.VK_RIGHT) { //movimenta o player para a direita
            if (playerX < 1400) {
                playerX += 10;
            }
        } else if (keyCode == KeyEvent.VK_SPACE) { //dispara
            isFiring = true;
        }

        repaint();   //é responsável por lidar com a atualização do ciclo de pintura
    }

    public void keyReleased(KeyEvent e) {          //é invocado quando a tecla deixar de ser pressionada
        if (e.getKeyCode() == KeyEvent.VK_SPACE) { //para de disparar quando largar o espaço
            isFiring = false;
        }
    }



    public void actionPerformed(ActionEvent e) {  //é invocado quando uma ação ocorre, por exemplo:
        if (isGameOver || isPaused) {             //quando o jogo acaba ou é pausado
            return;
        }

        for (Enemy enemy : enemies) {
            enemy.update();                       //é responsavel por atualizar os inimigos

            if (enemy.getY() >= 770) {
                isGameOver = true;                //se os inimigos chegarem à linha do player o jogo acaba
                break;
            }
        }

        if (isGameOver) {                         //quando o jogo acaba
            return;
        }

        if (isFiring && missiles.size() >= 10) {  //quando está a disparar ou quando o n de tiros é maior ou igual a 10
            isFiring = false;
        }

        Iterator<Missile> missileIterator = missiles.iterator(); //retorna um iterator (Um Iterator é um objeto que pode ser usado para percorrer coleções)
        while (missileIterator.hasNext()) {
            Missile missile = missileIterator.next();
            missile.update();

            if (missile.getY() < 0) { 
                missileIterator.remove();               //remove os tiros quando chegam no topo da tela
            } else {
                Iterator<Enemy> enemyIterator = enemies.iterator();
                while (enemyIterator.hasNext()) {
                    Enemy enemy = enemyIterator.next();
                    if (missile.getX() >= enemy.getX() && missile.getX() <= enemy.getX() + 40 && 
                            missile.getY() <= enemy.getY() + 20) {     //permite que o inimigo seja atingido de lado 
                        if (enemy.isBlue()) {                              
                            enemy.setBlue(false);                 //se o alien azul for atingido troca para vermelho
                        } else {
                            enemyIterator.remove();                    //remove o inimigo vermelho quando atingido         
                        }
                        missileIterator.remove();                      //também remove o tiro quando atinge o inimigo
                        break;
                    }
                }
            }
        }

        if (enemies.isEmpty()) {            //quando não há inimigos na tela 
            level++;                        //passa para o próximo nivel
            if (level % 5 == 0) {           //por cada 5 nivel completos aumenta o n maximo de inimigos po 1
                maxEnemies++;
            }
            enemySpeed += 0.15;             //vai aumentando a velocidade dos inimgos gradualmente
            createEnemies();
        }

        repaint();
    }

    public static void main(String[] args) {                  //main do codigo
        JFrame frame = new JFrame("Space Invaders");    //cria uma janela nova com o titulo Space Invaders
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //quando se clica no x fecha a janela

        SpaceInvaders game = new SpaceInvaders();             //inicia o jogo
        frame.add(game);                                      //adiciona o jogo à janela
        frame.pack();                                         //abre a janela grande o suficiente para que todos os itens caibam
        frame.setResizable(false);                  //não permite redimensionar a tela
        frame.setLocationRelativeTo(null);                  //seta a janela no centro da tela do pc
        frame.setVisible(true);                             //faz com que a janela seja visivel
    }

    private class Enemy {                     //construtor do inimigo
        private int x;
        private int y;
        private boolean isBlue;
        private boolean moveRight = true;

        public Enemy(int x, int y, boolean isBlue) { //cria o inimigo azul
            this.x = x;
            this.y = y;
            this.isBlue = isBlue;
        }

        public int getX() {             //vai buscar o valor de x
            return x;
        }

        public int getY() {             //vai buscar o valor de y
            return y;
        }

        public boolean isBlue() {      //vai verificar se é azul
            return isBlue;
        }

        public void setBlue(boolean blue) {  //vai ser azul se antes for verificado que relamente é
            isBlue = blue;
        }

        public void update() {
            if (moveRight) {
                x += enemySpeed;           //velocidade normal do alien
            } else {
                x -= enemySpeed;           //inverte a velocidade do inimigo
            }

            if (x >= 1420 || x <= 0) {     //quando o inimigo chega na borda na tela move-se para o outro lado
                y += 40;
                moveRight = !moveRight;
            }
        }
    }

    private class Missile {    //cria o tiro
        private int x;
        private int y;

        public Missile(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public int getX() {             //vai buscar o valor de x
            return x;
        }

        public int getY() {             //vai buscar o valor de y
            return y;
        }

        public void update() {          //velocidade do tiro
            y -= 12;
        }
    }
}
